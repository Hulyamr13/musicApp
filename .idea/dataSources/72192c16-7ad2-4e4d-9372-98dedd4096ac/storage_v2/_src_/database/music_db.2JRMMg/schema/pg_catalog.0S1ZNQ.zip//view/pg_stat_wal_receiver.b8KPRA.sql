create view pg_stat_wal_receiver
            (pid, status, receive_start_lsn, receive_start_tli, written_lsn, flushed_lsn, received_tli,
             last_msg_send_time, last_msg_receipt_time, latest_end_lsn, latest_end_time, slot_name, sender_host,
             sender_port, conninfo)
as
SELECT pid,
       status,
       receive_start_lsn,
       receive_start_tli,
       written_lsn,
       flushed_lsn,
       received_tli,
       last_msg_send_time,
       last_msg_receipt_time,
       latest_end_lsn,
       latest_end_time,
       slot_name,
       sender_host,
       sender_port,
       conninfo
FROM pg_stat_get_wal_receiver() s(pid, status, receive_start_lsn, receive_start_tli, written_lsn, flushed_lsn,
                                  received_tli, last_msg_send_time, last_msg_receipt_time, latest_end_lsn,
                                  latest_end_time, slot_name, sender_host, sender_port, conninfo)
WHERE pid IS NOT NULL;

alter table pg_stat_wal_receiver
    owner to postgres;

grant select on pg_stat_wal_receiver to public;

